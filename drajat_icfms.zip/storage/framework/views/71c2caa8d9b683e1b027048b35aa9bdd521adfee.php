<!doctype html>
<html class="fixed">
	<head>
		<!-- Basic -->
		<meta charset="UTF-8">
        <?php echo $__env->make('includes.taghead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</head>
	<body>
		<section class="body-sign">
            <?php echo $__env->yieldContent('content'); ?>;
        </section>
		<!-- Vendor -->
		<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	</body>
</html>
<?php /**PATH E:\ZCODESPACE\drajat_icfms\resources\views/layouts/front.blade.php ENDPATH**/ ?>