<?php $__env->startSection('modalBody'); ?>
    <?php
    $presentation = ['oral', 'poster', 'audience', 'keynote speaker'];
    $value = array_map('ucwords', $presentation);
    $listPresentation = array_combine($presentation, $value);
    array_unshift($listPresentation, '-- Choose Type --');
    ?>
    <div class="form-group mt-lg">
        <label class="col-sm-3 control-label">Presentation</label>
        <div class="col-sm-3">
            <?php echo Form::select('presentation', $listPresentation, [], ['class' => 'form-control input-sm']); ?>

            <?php echo Form::hidden('user_id', Auth::user()->id); ?>

        </div>
        <div class="col-sm-6">
            <?php echo Form::text('presenter', '', [
                'class' => 'form-control input-sm',
                'placeholder' => 'Presenter Name',
                'data-role' => 'tagsinput',
            ]); ?>

        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-3 control-label">Authors</label>
        <div class="col-sm-9">
            <?php echo Form::text('authors', '', ['class' => 'form-control input-sm']); ?>

            <small>If author more than one, separate by coma (,)</small>
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-3 control-label">Topic</label>
        <div class="col-sm-9">
            <?php
                array_unshift($topic, '-- Choose Topic --');
            ?>
            <?php echo Form::select('topic_id', $topic, [], ['class' => 'form-control input-sm']); ?>

        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-3 control-label">Abstract Title</label>
        <div class="col-sm-9">
            <?php echo Form::text('abstract_title', '', ['class' => 'form-control input-sm']); ?>

        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-3 control-label">Paper Title</label>
        <div class="col-sm-9">
            <?php echo Form::text('paper_title', '', ['class' => 'form-control input-sm']); ?>

        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-3 control-label">Abstract</label>
        <div class="col-sm-9">
            <?php echo Form::textarea('abstract', '', ['class' => 'form-control', 'rows' => '', 'cols' => '']); ?>

        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-3 control-label">Your Abstract File</label>
        <div class="col-sm-9">
            <?php echo Form::file('abstract_file', ['class' => 'form-control input-sm']); ?>

            <small>Only file with pdf,doc,docx,odt Extension allowed</small>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.modal', ['modalTitle' => $title, 'idForm' => 'fo-abstract', 'isLarge' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\ZCODESPACE\drajat_icfms\resources\views/pages/modal/abstractModal.blade.php ENDPATH**/ ?>