<?php $__env->startSection('title', 'Personal Detail | ICFMS ' . date('Y')); ?>
<?php $__env->startSection('title2', 'Personal Detail'); ?>

<?php $__env->startSection('content'); ?>
    <?php
    $title = ['Dr.', 'Prof.', 'Mr.', 'Mrs.'];
    $optTitle = array_combine($title, $title);
    ?>
    <div class="row">
        <div class="panel">
            <div class="panel-body">
                <div class="row">
                    <div class="col-md-10">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-session-status','data' => ['class' => 'alert alert-success']]); ?>
<?php $component->withName('auth-session-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'alert alert-success']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        <!-- Validation Errors -->
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'alert alert-danger','errors' => $errors]]); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'alert alert-danger','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        <form action="<?php echo e(route('personal.store')); ?>" method="POST" class="form-horizontal">
                            <?php echo csrf_field(); ?>
                            <?php echo Form::hidden('user_id', $user->user_id); ?>

                            <div class="form-group">
                                <label class="control-label col-sm-3">Title </label>
                                <div class="col-sm-3">
                                    <?php echo Form::select('title', $optTitle, $user->title, ['class' => 'form-control']); ?>

                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3">Name</label>
                                <div class="col-sm-3">
                                    <?php echo Form::text('firstname', $user->firstname, ['placeholder' => 'First name', 'class' => 'form-control']); ?>

                                </div>
                                <div class="col-sm-3">
                                    <?php echo Form::text('midlename', $user->midlename, ['placeholder' => 'Middle name (Optional)', 'class' => 'form-control']); ?>

                                </div>
                                <div class="col-sm-3">
                                    <?php echo Form::text('lastname', $user->lastname, ['placeholder' => 'Last name', 'class' => 'form-control']); ?>

                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3">Affilation</label>
                                <div class="col-sm-6">
                                    <input type="text" value="<?php echo e($user->affiliation); ?>" name="affiliation" class="form-control">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3">Address (Optional)</label>
                                <div class="col-sm-6">
                                    <textarea name="address" class="form-control"><?php echo e($user->address); ?></textarea>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3">Country</label>
                                <div class="col-sm-6">
                                    <?php
                                        $listCountry = array_combine($country, $country);
                                        array_unshift($listCountry, '-- Choose Country --');
                                    ?>
                                    <?php echo Form::select('country', $listCountry, $user->country, ['class' => 'form-control']); ?>

                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3">Main Email</label>
                                <div class="col-sm-6">
                                    <input type="email" name="email" class="form-control" value="<?php echo e(Auth::user()->email); ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3">2<sup>nd</sup> Email (Optional)</label>
                                <div class="col-sm-6">
                                    <input type="email" name="secondemail" class="form-control" value="<?php echo e($user->secondemail); ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3">Contact Number</label>
                                <div class="col-sm-3">
                                    <?php echo Form::text('mobilenumber', $user->mobilenumber, ['placeholder'=>"Mobile Number",'class'=>"form-control"]); ?>

                                </div>
                                <div class="col-sm-3">
                                    <?php echo Form::text('phonenumber', $user->phonenumber, ['placeholder'=>"Phone Number",'class'=>"form-control"]); ?>

                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-9 text-right">
                                    <button type="submit" class="btn btn-sm btn-success"><i class="fa fa-save"></i>&nbsp;Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\ZCODESPACE\drajat_icfms\resources\views/pages/personal.blade.php ENDPATH**/ ?>