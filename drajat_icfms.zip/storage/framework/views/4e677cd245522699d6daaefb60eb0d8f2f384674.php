<?php $__env->startSection('title', 'Registration ICFMS 2022'); ?>

<?php $__env->startSection('content'); ?>
    <div class="center-sign">
        <a href="/" class="logo pull-left">
            <h3>Registration Form</h3>
        </a>
        <div class="panel panel-sign">
            <div class="panel-title-sign mt-xl text-right">
                <h2 class="title text-uppercase text-weight-bold m-none"><i class="fa fa-user mr-xs"></i> Sign Up</h2>
            </div>
            <div class="panel-body">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'alert alert-danger','errors' => $errors]]); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'alert alert-danger','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <form id="fo-register" action="<?php echo e(route('register')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php
                        $title = ['Dr.', 'Prof.', 'Mr.','Mrs.'];
                        $optTitle = array_combine($title, $title);
                    ?>
                    <fieldset>
                        <legend>Personal Details</legend>
                        <div class="form-group">
                            <label>Title</label>
                            <?php echo Form::select('title', $optTitle,old('title'),['class' => 'form-control input-sm']); ?>

                        </div>
                        <div class="form-group">
                            <label>First Name</label>
                            <input name="firstname" type="text" class="form-control input-sm" value="<?php echo e(old('firstname')); ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Midle Name</label>
                            <input name="midlename" type="text" class="form-control input-sm" value="<?php echo e(old('midlename')); ?>">
                        </div>
                        <div class="form-group">
                            <label>Last Name</label>
                            <input name="lastname" type="text" class="form-control input-sm" value="<?php echo e(old('lastname')); ?>" required>
                        </div>
                    </fieldset>
                    <fieldset class="mt-lg mb-lg">
                        <legend>Contact Details</legend>
                        <div class="form-group">
                            <label>Main Email</label>
                            <input type="text" class="form-control input-sm" name="email" value="<?php echo e(old('email')); ?>">
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Password</label>
                                    <input name="password" type="password" class="form-control input-sm" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Re-Type Password</label>
                                    <input name="password_confirmation" id="re-password" type="password" class="form-control input-sm">
                                </div>
                            </div>
                        </div>
                        <div class="form-group mt-sm">
                            <label>2<sup>nd</sup>Email (optional)</label>
                            <input name="secondemail" type="email" class="form-control input-sm" value="<?php echo e(old('secondemail')); ?>">
                        </div>
                        <div class="form-group">
                            <label>Affiliation</label>
                            <input name="affiliation" type="text" class="form-control input-sm" value="<?php echo e(old('affiliation')); ?>">
                        </div>
                        <div class="form-group">
                            <label>Address (Optional)</label>
                            <textarea name="address" id="" class="form-control"><?php echo e(old('address')); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label>Country</label>
                            <?php
                                $country = array_combine($negara, $negara);
                                array_unshift($country, '-- Choose Country --');
                            ?>
                            <?php echo Form::select('country', $country, old('country'), ['class' =>'form-control']); ?>

                        </div>
                        <div class="row mb-md">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Mobile Number</label>
                                    <input value="<?php echo e(old('mobilenumber')); ?>" name="mobilenumber" type="text" class="form-control input-sm">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Phone Number</label>
                                    <input name="phonenumber" value="<?php echo e(old('phonenumber')); ?>" type="text" class="form-control input-sm">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-offset-8 col-md-4 text-right">
                                <button type="button" id="btn-submit" class="btn btn-primary">Sign Up</button>
                            </div>
                        </div>
                    </fieldset>

                    <p class="text-center">Already have an account? <a href="/">Sign In!</a></p>
                </form>
            </div>
        </div>

        <p class="text-center text-muted mt-md mb-md">&copy; Copyright 2022. All Rights Reserved.</p>
    </div>
<?php $__env->stopSection(); ?>
<?php if (! $__env->hasRenderedOnce('3a43d24c-4304-47da-9812-f1726a069803')): $__env->markAsRenderedOnce('3a43d24c-4304-47da-9812-f1726a069803'); ?>
<?php $__env->startPush('js'); ?>
    <script type="text/javascript">
        $(document).on('click','#btn-submit',function(evt) {
            let re = $('#re-password'), pas = $('input[name="password"]');
            if(pas.val() == ''){
                alert('Password Still Empty');
                pas.focus();
            }else if(pas.val() != re.val()){
                alert('Password not match');
                re.val('');
                pas.focus();
            }else{
                $('form#fo-register').submit();
            }
        });
    </script>
<?php $__env->stopPush(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\ZCODESPACE\drajat_icfms\resources\views/front/registration.blade.php ENDPATH**/ ?>