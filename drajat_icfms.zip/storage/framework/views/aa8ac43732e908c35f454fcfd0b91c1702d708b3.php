<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog <?php if($isLarge??false): ?>
        modal-lg
    <?php endif; ?>">

        <div class="modal-content">
            <form id="<?php echo e($idForm); ?>">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title"><?php echo e($modalTitle); ?></h4>
                </div>
                <div class="modal-body">
                    <?php echo $__env->yieldContent('modalBody'); ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-sm btn-default" data-dismiss="modal">Close</button>
                    <?php
                        $hideSubmit = ($isSubmit??true)?'':'hidden';
                    ?>
                    <button type="submit" class="btn btn-sm btn-success <?php echo e($hideSubmit); ?>"><i class="fa fa-save"></i>&nbsp;Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH E:\ZCODESPACE\drajat_icfms\resources\views/layouts/modal.blade.php ENDPATH**/ ?>