<?php

function renderSubMenu($value, $currentUrl)
{
    $isActiveChildUrl = false;
    $isParentActive = false;
    $subMenu = '';
    foreach ($value as $key => $menu) {
        $subSubMenu = '';
        $hasTitle = !empty($menu['title']) ? $menu['title'] : '';
        $hasSubTitle = !empty($menu['subTitle']) ? $menu['subTitle'] : '';

        $isActiveChildUrl = $currentUrl == $menu['url'];
        if ($isActiveChildUrl && !$isParentActive) {
            $isParentActive = true;
        }
        $active = $isActiveChildUrl ? 'nav-active' : '';
        $subMenu .=
            '<li class="nav-item '.$active.'">
            <a class="nav-link" href="' .$menu['url'] .'"
                title="' .$hasSubTitle .'" >' .
            $hasTitle .
            '</a></li>';
    }
    return ['subMenu' => $subMenu, 'parentActive' => $isParentActive];
}

function renderMenu()
{
    $return = '';
    $currentUrl = Request::path();
    foreach (config('sidebar.menu') as $key => $menu) {
        $isActive = $currentUrl == $menu['url'];
        $menu['url'] = URL::to($menu['url']);
        if (!in_array(Session::get('icfms_tipe_login'), $menu['akses'])) {
            continue;
        }

        $idMenu = 'navbar-' . str_replace(' ', '', $menu['title']);
        $hasSub = !empty($menu['sub_menu']) ? 'nav-parent' : '';
        $isParent = !empty($menu['sub_menu']) ? 'data-toggle="collapse" role="button" ' . 'aria-expanded="false" aria-controls="'.$idMenu.'" ' : '';
        $hasIcon = !empty($menu['icon']) ? '<i class="fa '. $menu['icon'] .'"></i>' : '';
        $hasTitle = !empty($menu['title']) ? '<span>' . $menu['title'] . '</span>' : '';
        $hasSubTitle = !empty($menu['subTitle']) ? $menu['subTitle'] : '';

        $subMenu = '';
        $isParentActive = false;
        $show = '';
        if (!empty($menu['sub_menu'])) {
            $render = renderSubMenu($menu['sub_menu'], $currentUrl, $menu['title']);
            $isParentActive = $render['parentActive'];
            $show = $isParentActive ? 'nav-expanded' : '';
            $subMenu .= '<ul class="nav nav-children">';
            $subMenu .= $render['subMenu'];
            $subMenu .= '   </ul>';
            $menu['url'] = '#' . $idMenu;
        }

        $activeText = $isActive ? 'nav-active' : '';

        $return .=
            '<li class="'. $activeText.' '.$hasSub.' '.$show.'">
            <a title="' .$hasSubTitle .'" href="' .$menu['url'] .'">' .
            $hasIcon .
            '' .
            $hasTitle .
            '</a>' .
            $subMenu .
            '</li>';
    }
    return $return;
}
?>
<div class="sidebar-header">
    <div class="sidebar-title">
        &nbsp;
    </div>
    <div class="sidebar-toggle hidden-xs" data-toggle-class="sidebar-left-collapsed" data-target="html"
        data-fire-event="sidebar-left-toggle">
        <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
    </div>
</div>

<div class="nano">
    <div class="nano-content">
        <nav id="menu" class="nav-main" role="navigation">
            <ul class="nav nav-main">
                <?php echo renderMenu(); ?>

            </ul>
        </nav>

        <hr class="separator" />
    </div>

</div>
<?php /**PATH E:\ZCODESPACE\drajat_icfms\resources\views/includes/sidebar.blade.php ENDPATH**/ ?>