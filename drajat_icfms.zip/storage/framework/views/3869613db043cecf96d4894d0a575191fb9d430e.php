<script src="<?php echo e(asset('vendor/jquery/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/jquery-browser-mobile/jquery.browser.mobile.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/nanoscroller/nanoscroller.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/magnific-popup/magnific-popup.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/jquery-placeholder/jquery.placeholder.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/pnotify/pnotify.custom.js')); ?>"></script>

<!-- Specific Page Vendor -->

<!-- Theme Base, Components and Settings -->
<script src="<?php echo e(asset('js/bootbox.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.buttons.min.js')); ?>"></script>

<!-- Theme Initialization Files -->

<script src="<?php echo e(asset('js/ownjs.js')); ?>"></script>
<?php echo $__env->yieldPushContent('js'); ?>;
<?php /**PATH E:\ZCODESPACE\drajat_icfms\resources\views/includes/footer.blade.php ENDPATH**/ ?>