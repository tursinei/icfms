<header class="page-header">
    <h2><?php echo $__env->yieldContent('title2'); ?></h2>

    
</header>
<?php /**PATH E:\ZCODESPACE\drajat_icfms\resources\views/includes/breadcumbs.blade.php ENDPATH**/ ?>