
<?php if(session('success')): ?>
<div <?php echo e($attributes); ?>>
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>
<?php /**PATH E:\ZCODESPACE\drajat_icfms\resources\views/components/auth-session-status.blade.php ENDPATH**/ ?>