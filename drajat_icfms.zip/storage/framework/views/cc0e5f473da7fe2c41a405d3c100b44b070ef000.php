<!doctype html>
<html class="fixed">
	<head>
		<!-- Basic -->
		<meta charset="UTF-8">
        <?php echo $__env->make('includes.taghead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</head>
	<body>
		<section class="body">
			<!-- start: header -->
			<header class="header">
				<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<!-- end: search & user box -->
			</header>
			<!-- end: header -->

			<div class="inner-wrapper">
				<!-- start: sidebar -->
				<aside id="sidebar-left" class="sidebar-left">
                    <?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				</aside>
				<!-- end: sidebar -->
				<section role="main" class="content-body">
					<?php echo $__env->make('includes.breadcumbs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<!-- start: page -->
                    <?php echo $__env->yieldContent('content'); ?>
					<!-- end: page -->
				</section>
			</div>
			<!-- Vendor -->
			<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</section>
	</body>
</html>
<?php /**PATH E:\ZCODESPACE\drajat_icfms\resources\views/layouts/master.blade.php ENDPATH**/ ?>